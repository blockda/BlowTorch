
hp_threshold_low = nil
healcmd = nil

sent_heal = false

function incomingdata(name,line,replacemap)
	local curhp = replacemap["1"]
	local maxhp = replacemap["2"]
	local pcthp = curhp / maxhp
	
	-- Note(string.format("\nAuto-heal data: %d/%d %d\n",curhp,maxhp,pcthp*100))
	
	-- Need to determine whether the command has been sent and received by the server before issuing it again
		        	
	if (pcthp < hp_threshold_low ) then
		if (not sent_heal) then
			SendToServer(healcmd)
			sent_heal = true
		end
	end 
	
end 

function heal_received()
	sent_heal = false
end

-- Everything below here handles the options
function OnOptionChanged(key,value)
	local func = optionsTable[key]
	if(func ~= nil) then
		func(value)
	end
end

function setHealString(val)
	healcmd = val
end

function setHpThresh(val)
	hp_threshold_low = val / 100
end

optionsTable = {}
optionsTable.hp_threshold = setHpThresh
optionsTable.heal_cmd = setHealString