package com.happygoatstudios.bt.launcher;

public interface ReadyListener {
	public void ready(String displayname,String host,String port);
}
