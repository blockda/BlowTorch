package com.happygoatstudios.bt.window;

import java.io.UnsupportedEncodingException;

import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.MotionEvent;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.webkit.WebSettings.TextSize;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.happygoatstudios.bt.R;
//import com.happygoatstudios.bt.service.BaardTERMService;
import com.happygoatstudios.bt.service.*;

public class BaardTERMWindow extends Activity {
	
	String host;
	int port;
	
	Handler myhandler = null;
	boolean servicestarted = false;
	
	IBaardTERMService service = null;
	
	
	Processor the_processor = null;
	
	final static public int MESSAGE_PROCESS = 102;
	protected static final int MESSAGE_PROCESSED = 104;
	protected static final int MESSAGE_SENDDATAOUT = 105;
	
	GestureDetector gestureDetector = null;
	OnTouchListener gestureListener = null;
	
	ScrollView screen1 = null;
	//ScrollView screen2 = null;
	SlickView screen2 = null;
	ScrollView screen3 = null;
	EditText input_box = null;
	CommandKeeper history = null;
	
	boolean isBound = false;
	
	SpannableStringBuilder the_buffer = null;
	
	private ServiceConnection mConnection = new ServiceConnection() {

		public void onServiceConnected(ComponentName arg0, IBinder arg1) {
			service = IBaardTERMService.Stub.asInterface(arg1); //turn the binder into something useful
			
			//register callback
			try {
				service.registerCallback(the_callback);
				
			} catch (RemoteException e) {
				//do nothing here, as there isn't much we can do
			}
			
			
			finishInitializiation();
			
		}

		public void onServiceDisconnected(ComponentName arg0) {
			try {
				//Log.e("WINDOW","Attempting to unregister the callback due to unbinding");
				service.unregisterCallback(the_callback);
			} catch (RemoteException e) {
				//do nothing here, as there isn't much we can do
			}
			
			service = null;
		}
		
	};
	
	Pattern newline = Pattern.compile("\n");
	//Pattern newline = Pattern.compile("[\\x0D][\\x0A]");

	public Bundle CountNewLine(String ISOLATINstring,int maxlines) {
		
		Matcher match = newline.matcher(ISOLATINstring);
		
		int prunelocation = 0;
		int numberfound = 0;
		//boolean found = false;
		while(match.find()) {
			numberfound++;	
		}
		
		
		
		if(numberfound > maxlines) {
			int numtoprune = numberfound - maxlines;
			match.reset();
			for(int i = 0;i < numtoprune;i++) {
				if(match.find()) { //shouldalways be true
					prunelocation = match.start();
				}
			}
			//by the time we are here, the prunelocation is known
		}
		Log.e("WINDOW","FOUND: " + numberfound + " with prune location at: " + prunelocation);
		
		Bundle dat = new Bundle();
		dat.putInt("TOTAL", numberfound);
		dat.putInt("PRUNELOC", prunelocation);
		
		return dat;
	}
	
	public boolean finishStart = true;
	
	String html_buffer = new String();
	
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		
		//Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
		
		setContentView(R.layout.window_layout);
		
		TextView tv = (TextView)findViewById(R.id.tv);
		tv.setPaintFlags(Paint.DITHER_FLAG|Paint.LINEAR_TEXT_FLAG); //no flags, see Paint.<FLAG> to turn stuff on.
		
		//set up the flinger
        gestureDetector = new GestureDetector(new BgestureListener(this));
        gestureListener = new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                if (gestureDetector.onTouchEvent(event)) {
                    return true;
                }
                return false;
            }
        };
        
        WebView wview = (WebView)findViewById(R.id.webview);
        //wview.getSettings().setTextSize(TextSize.SMALLEST);
        wview.getSettings().setStandardFontFamily("Serrif");
        
        wview.loadData("<html><body style=\"background-color:black;\"><span style=\"background-color:black;color:red;font-size=\"12px\";generic-family:monospace;\"><b>LSDJFLSDKJFHELLO FOLKS</b><br>A<br>b<br>d<br>c<br><br><br>f<br><br>A<br>b<br>d<br>c<br><br><br>f<br></span></body></html>", "text/html", "utf-8");
        
        
        
        history = new CommandKeeper(10);
        
        screen1 = (ScrollView)findViewById(R.id.mainscroller);
        //screen2 = (ScrollView)findViewById(R.id.secscroller);
        screen2 = (SlickView)findViewById(R.id.slickview);
        RelativeLayout l = (RelativeLayout)findViewById(R.id.slickholder);
        screen2.setParentLayout(l);
        //screen3 = (ScrollView)findViewById(R.id.thrirdscroller);
        
        FixedViewFlipper flipper = (FixedViewFlipper)findViewById(R.id.flippdipper);
        flipper.showNext();
        
        screen1.setOnTouchListener(gestureListener);
        screen2.setOnTouchListener(gestureListener);
        
       
       // screen3.setOnTouchListener(gestureListener);
        
		
		screen1.setVerticalFadingEdgeEnabled(false);
		//screen2.setVerticalFadingEdgeEnabled(false);
		//screen3.setVerticalFadingEdgeEnabled(false);
		
        input_box = (EditText)findViewById(R.id.textinput);
        
        input_box.setOnKeyListener(new TextView.OnKeyListener() {

			public boolean onKey(View v, int keyCode, KeyEvent event) {
				
				if(event.getKeyCode() == KeyEvent.KEYCODE_DPAD_UP && event.getAction() == KeyEvent.ACTION_UP) {
					
					String cmd = history.getNext();
					input_box.setText(cmd);
					return true;
				} else if(event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN && event.getAction() == KeyEvent.ACTION_UP) {
					String cmd = history.getPrev();
					input_box.setText(cmd);
					return true;
				}
				return false;
			}
   
        });
        
        
        
        input_box.setOnEditorActionListener(new TextView.OnEditorActionListener() {
        //input_box.setOnKeyListener(new EditText.OnKeyListener() {

        
		public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		//public boolean onKey(View v, int keyCode, KeyEvent event) {
				
				//post message to conneciton thread
				//only do something if enter was pressed
				if(event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
					//Message tmp = ConnectionHandler.obtainMessage(105);
					String data = input_box.getText().toString();
					history.addCommand(data);
					Character cr = new Character((char)13);
					Character lf = new Character((char)10);
					String crlf = cr.toString() + lf.toString();
					data = data.concat(crlf);
					ByteBuffer buf = ByteBuffer.allocate(data.length());
				
					try {
						buf.put(data.getBytes("UTF-8"));
					} catch (UnsupportedEncodingException e) {
						
						e.printStackTrace();
					}
				
					buf.rewind();
				
					byte[] buffbytes = buf.array();
					//Bundle bundle = new Bundle();
					//bundle.putByteArray("DATA", buffbytes);
					//tmp.setData(bundle);
					//ConnectionHandler.sendMessage(tmp);
					try {
						service.sendData(buffbytes);
					} catch (RemoteException e) {
						e.printStackTrace();
					}
					
					//send the box to the window, with newline because we are cool.
					//but delete that pesky carriage return, yuck
					data.replace(cr.toString(), "\n");
					screen2.addText(data);
					screen2.jumpToZero();
				
					input_box.setText("");
					return true;
				} else if(event.getKeyCode() == KeyEvent.KEYCODE_DPAD_UP && event.getAction() == KeyEvent.ACTION_UP) {
					String cmd = history.getNext();
					input_box.setText(cmd);
					return true;
				} else {
					return true;
				}
				//return false;
			}
		});
        
        

		
		//assign my handler
		myhandler = new Handler() {
			public void handleMessage(Message msg) {
				switch(msg.what) {
				case MESSAGE_PROCESS:
					try {
						Spannable data = the_processor.DoProcess(msg.getData().getByteArray("SEQ"));
						
						TextView tv = (TextView)findViewById(R.id.tv);
						
						tv.append(data);
						//set window text to data.
						
					} catch (UnsupportedEncodingException e) {
						
						//e.printStackTrace();
					}
					break;
				case MESSAGE_PROCESSED:
					TextView tv = (TextView)findViewById(R.id.tv);
					
					CharSequence seq = msg.getData().getCharSequence("SEQ");
					if(seq != null) {
						the_buffer.append(seq);
					}
					//prune
					//the_buffer.append(sstr);
					Bundle datal = null;
					try {
						datal = CountNewLine(new String(the_buffer.toString().getBytes("ISO-8859-1"),"ISO-8859-1"),30);
					} catch (UnsupportedEncodingException e) {
						//nothing to do, that's messed that they don't support isolatin
					}
					if(datal.getInt("TOTAL") > 30) {
						Log.e("WINDOW","TIME TO PRUNE AT: " + datal.getInt("PRUNELOC") + " FOUND " + datal.getInt("TOTAL") + " lines.");
						Object[] unusedspans = the_buffer.getSpans(0, datal.getInt("PRUNELOC"), Object.class);
						for(int i=0;i<unusedspans.length;i++) {
							the_buffer.removeSpan(unusedspans[i]);
						}
						Object[] array = the_buffer.getSpans(0,the_buffer.length(),Object.class);
						int size = array.length;
						Log.e("WINDOW","FOUND: " + size + " spans.\n");
						the_buffer.replace(0, datal.getInt("PRUNELOC"), "");
						
					}
					
					tv.setText(the_buffer);
					
					
					
					//TODO: don't scroll unless the scroll position is at the bottom.
					screen1.post(new Runnable() {
						public void run() {
							ScrollView tmp = (ScrollView)findViewById(R.id.mainscroller);

							
							tmp.fullScroll(ScrollView.FOCUS_DOWN);
							
							EditText tmpedit = (EditText)findViewById(R.id.textinput);
							tmpedit.requestFocus();
						}
					});
					break;
				case MESSAGE_HTMLINC:
					WebView web = (WebView)findViewById(R.id.webview);
					//web.getSettings().setStandardFontFamily("courier new");
					//web.getSettings().setFixedFontFamily("monospace");
					web.getSettings().setJavaScriptEnabled(true);
					//web.getSettings().set
					String html_header = "<html><head>" +
							"<style type=\"text/css\">" +
							".mybod{background-color:#555555;width:520px;" +
							"font-family:\"courier\";font-size:0.8em;" +
							"padding:0;margin:0;}</style>" +
							"</head><body class=mybod><div class=mybod>";
					String html_footer = "</div></body></html>";
					
					html_buffer = html_buffer.concat(msg.getData().getString("HTML"));
					
					//TextView debug_screen = (TextView)findViewById(R.id.tv2);
					//debug_screen.setText(html_buffer);
					
					//web.destroy();
					//web.load
					web.loadDataWithBaseURL("fake:////url.is.fake",html_header + html_buffer + html_footer, "text/html", "us-ascii","fake:////url.is.fake");
					Log.e("WINDOW","HTML DRAW ATTEMPTED WITH:" + html_buffer);
					break;
				case MESSAGE_RAWINC:
					//raw data incoming
					screen2.addText(msg.getData().getString("RAW"));
					break;
				case MESSAGE_SENDDATAOUT:
					byte[] data = msg.getData().getByteArray("DATA");
					try {
						service.sendData(data);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					screen2.addText(new String(data));
					break;
				default:
					break;
				}
			}
		};
		
		
		
		//start the service if it isn't already started, a call to Context.startService shouldn't start a new service if it is already launched.
		//the icicle should contain a boolean to see if we have already started the service
		/*if(icicle != null) {
			Log.e("WINDOW","STARTED WITH SAVED INSTANCE STATE");
			servicestarted = icicle.getBoolean("CONNECTED");
			finishStart = icicle.getBoolean("FINISHSTART");
			if(servicestarted) {
				Log.e("WINDOW","SERVICE ALREADY STARTED!");
			}
		}*/
		screen2.setDispatcher(myhandler);
		screen2.setInputType(input_box);
		
		//icicile is out, prefs are in
		SharedPreferences prefs = this.getSharedPreferences(PREFS_NAME,0);
		
		servicestarted = prefs.getBoolean("CONNECTED",false);
		finishStart = prefs.getBoolean("FINISHSTART", true);
		
		String buttons = prefs.getString("BUTTONS", null);
		Log.e("WINDOW","WORKING ON STRING" +buttons);
		if(buttons != null && buttons != "") {
			String[] b_line = buttons.split("&&");
			for(int i=0;i<b_line.length;i++) {
				Log.e("WINDOW","WORKING ON BUTTON" + b_line[i]);
				String[] elements = (b_line[i]).split("\\|\\|");
				for(int z = 0;z<elements.length;z++) {
					Log.e("WINDOW","ELEMENT:" + elements[z]);
				}
				//Log.e("WINDOW","SPLIT INTO X:"+elements[0] + " Y: "+elements[1] + " STR:" + elements[2]);
				int x = new Integer(elements[0]).intValue();
				int y = new Integer(elements[1]).intValue();
				String str = null;
				if(elements.length > 2) {
					str = elements[2];
				} else {
					str = "";
				}
				
				Message msg = screen2.buttonaddhandler.obtainMessage(SlickView.MSG_CREATEBUTTON);
				Bundle b = msg.getData();
				b.putInt("X", x);
				b.putInt("Y", y);
				b.putString("THETEXT",str);
				msg.setData(b);
				screen2.buttonaddhandler.sendMessage(msg);
				
			}
		}
		
		//get the saved buffer from the prefs
		if(icicle != null) {
			CharSequence seq = icicle.getCharSequence("BUFFER");
			if(seq != null) {
				//the_buffer = new SpannableStringBuilder();
				screen2.setBuffer((new StringBuffer(seq).toString()));
			} else {
				//the_buffer = new SpannableStringBuilder();
				
			}
		} else {
			//the_buffer = new StringBuffer();
		}
		
		if(!servicestarted) {
			//start the service
			this.startService(new Intent(com.happygoatstudios.bt.service.IBaardTERMService.class.getName()));
			servicestarted = true;
		}
		
		
		//give it some time to launch
		synchronized(this) {
			try {
				this.wait(500);
			} catch (InterruptedException e) {
				//e.printStackTrace();
			}
		}
		
		//if the service was already started, just bind to the service.
		//bindService(new Intent(com.happygoatstudios.bt.service.IBaardTERMService.class.getName()), mConnection, 0); //do not auto create
		//isBound = true;
		//Log.e("WINDOW","Bound service in onCreate()");
		//if(passed) {
		//	Log.e("STUFF","KALU-KALE! BINDSERVICE RETURNED TRUE");
		//}
		//after successful binding, we need to set the connection data provided to us by the launcher.
		
		
	
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
		
		menu.add(0,100,0,"Triggers");
		menu.add(0,101,0,"Options");
		menu.add(0,102,0,"Slick Buttons");
		
		return true;
		
	}
	
	public void onBackPressed() {
		//Log.e("WINDOW","BACK PRESSED TRAPPED");
		
		//show dialog
		AlertDialog.Builder builder = new AlertDialog.Builder(BaardTERMWindow.this);
		builder.setMessage("Keep service running in background?");
		builder.setCancelable(true);
		builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
		           public void onClick(DialogInterface dialog, int id) {
		                BaardTERMWindow.this.dirtyExit();
		                BaardTERMWindow.this.finish();
		           }
		       });
		builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
		           public void onClick(DialogInterface dialog, int id) {
		                //dialog.cancel();
		        	   BaardTERMWindow.this.cleanExit();
		        	   BaardTERMWindow.this.finish();
		           }
		       });
		//AlertDialog alert = builder.create();
		builder.create();
		builder.show();
		//alert.show();
		
		//super.onBackPressed();
	}
	
	public void cleanExit() {
		//we want to kill the service when we go.
		
		//shut down the service
		if(isBound) {
			try {
				//Log.e("WINDOW","Attempting to unregister the callback due to unbinding");
				if(service != null) {
					service.unregisterCallback(the_callback);
				}
			} catch (RemoteException e) {
				//e.printStackTrace();
			}
			
			unbindService(mConnection);
			
			
			
			isBound = false;
			//Log.e("WINDOW","Unbound connection at cleanExit");
		}
		
		
		finishStart = true;
		servicestarted = false;
		
		saveSettings();
		
		stopService(new Intent(com.happygoatstudios.bt.service.IBaardTERMService.class.getName()));
		
	}
	
	public void dirtyExit() {
		//we dont want to kill the service
		if(isBound) {
			
			try {
				//Log.e("WINDOW","Attempting to unregister the callback due to unbinding");
				SlickView sv = (SlickView)findViewById(R.id.slickview);
				service.saveBuffer(sv.getBuffer());
				service.unregisterCallback(the_callback);
			} catch (RemoteException e) {
				//e.printStackTrace();
			}
			
			unbindService(mConnection);
			//Log.e("WINDOW","Unbound connection at cleanExit");
			isBound = false;
		}
		
		//save settings
		finishStart = false;
		servicestarted = true;
		//this.onPause();
		saveSettings();
	}
	
	public void onSaveInstanceState(Bundle data) {
		//Log.e("WINDOW","App being paused, onSaveInstanceState");
		//data.putBoolean("CONNECTED", servicestarted);
		//data.putBoolean("FINISHSTART", finishStart);
		SlickView sv = (SlickView)findViewById(R.id.slickview);
		data.putCharSequence("BUFFER", sv.getBuffer());
		//Log.e("WINDOW","SAVING STATE WITH BUFFER: " + sv.getBuffer());
		
		
	}
	
	public void onRestoreInstanceState(Bundle data) {
		//Log.e("WINDOW","App being restored, onRestoreInstanceState");
		//servicestarted = data.getBoolean("CONNECTED");
		//finishStart = data.getBoolean("FINISHSTART");
		//the_buffer = new SpannableStringBuilder(data.getCharSequence("BUFFER"));
		SlickView sv = (SlickView)findViewById(R.id.slickview);
		sv.setBuffer((new StringBuffer(data.getCharSequence("BUFFER")).toString()));
		//Log.e("WINDOW","RESTORE STATE:"+ (new StringBuffer(data.getCharSequence("BUFFER")).toString()));
	}
	
	
	public static final String PREFS_NAME = "CONDIALOG_SETTINGS";
	protected static final int MESSAGE_HTMLINC = 110;
	protected static final int MESSAGE_RAWINC = 111;
	
	public void saveSettings() {
		//shared preferences
		SharedPreferences prefs = this.getSharedPreferences(PREFS_NAME,0);
		
		SharedPreferences.Editor editor = prefs.edit();
		
		editor.putBoolean("CONNECTED", servicestarted);
		editor.putBoolean("FINISHSTART", finishStart);
		
		//build the slickviews string arrays for buttons.
		SlickView sv = (SlickView)findViewById(R.id.slickview);
		Vector<SlickButton> btns = sv.buttons;
		Iterator<SlickButton> itrator = btns.listIterator();
		
		Vector<String> bstrings = new Vector<String>();
		StringBuffer serialbuttons = new StringBuffer();
		while(itrator.hasNext()) {
			SlickButton b = itrator.next();
			String str = new String(b.x +"||" +b.y + "||"+b.getText());
			serialbuttons.append(str + "&&");
			Log.e("WINDOW","SERIALIZING: " + str);
			
			bstrings.add(str);
		}
		
		editor.putString("BUTTONS", serialbuttons.toString());
		
		//String[] strings = (String[])bstrings.toArray();
		//for(int i = 0;i<strings.length;i++) {
			
		//}
		
		//actually put it in the bundle
		//editor.put
		
		editor.commit();
		
		String str = "Save settings: ";
		if(servicestarted) {
			str = str + " servicestatred=true";
		} else {
			str = str + " servicestatred=false";
		}
		
		if(finishStart) {
			str = str + " finishStart=true";
		} else {
			str = str + " finishStart=false";
		}
		
		//Log.e("WINDOW",str);
		
	}
	
	public void onStart() {
		Log.e("SLIC","HOLY LORD ON START CALLED!!!!!!!!!!!!!!!!");
		super.onStart();
	}
	

	
	public void onPause() {
		if(isBound) {
			
			try {
				//Log.e("WINDOW","Attempting to unregister the callback due to unbinding");
				service.unregisterCallback(the_callback);
			} catch (RemoteException e) {
				//e.printStackTrace();
			}
			
			unbindService(mConnection);
			//Log.e("WINDOW","Unbound connection at onPause");
			isBound = false;
		}
		
		//Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
		
		saveSettings();
		
		//SlickView sv = (SlickView)findViewById(R.id.slickview);
		//sv.stopDrawing();
		
		super.onPause();
		
		//this.finish();
	}
	
	public void onResume() {
		
		
		
		Log.e("WINDOW","ONRESUME CALLED!");
		//Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
		
		SharedPreferences prefs = this.getSharedPreferences(PREFS_NAME,0);
		servicestarted = prefs.getBoolean("CONNECTED", false);
		finishStart = prefs.getBoolean("FINISHSTART", true);
		
		
		String str = "Load settings (onResume): ";
		if(servicestarted) {
			str = str + " servicestatred=true";
		} else {
			str = str + " servicestatred=false";
		}
		
		if(finishStart) {
			str = str + " finishStart=true";
		} else {
			str = str + " finishStart=false";
		}
		
		//Log.e("WINDOW",str);
		
		
		if(!isBound) {
			bindService(new Intent(com.happygoatstudios.bt.service.IBaardTERMService.class.getName()), mConnection, 0); //do not auto create
			//Log.e("WINDOW","Bound connection at onResume");
			isBound = true;
		}
		
		//SlickView sv = (SlickView)findViewById(R.id.slickview);
		//sv.startDrawing();
		

		
		/*if(service != null) {
		try {
			service.requestBuffer();
		} catch (RemoteException e) {
			//e.printStackTrace();
		}
		}*/
		super.onResume();
	}
	
	public void onDestroy(Bundle saveInstance) {
		//Log.e("WINDOW","App being destroyed, saving state");
		//unbindService(mConnection);
		super.onDestroy();
	}
	
	
	
	
	
	private void finishInitializiation() {
		Intent myintent = this.getIntent();
		
		//the_processor = new Processor(myhandler,service);
		
		if(!finishStart) {
			//service is already started, skip init by returning
			//Log.e("WINDOW","RETURNING BECAUSE THE SERVICE IS ALREADY STARTED!");
			try {
				service.requestBuffer();
			} catch (RemoteException e) {
				//e.printStackTrace();
			}
			return;
		} else {
			//Log.e("WINDOW","FINISHING INITIALIZATION BECAUSE THE SERVICE JUST BOOTED UP!");
		}
		
		finishStart = false;
		
		//get extra data from the intent;
		//String display = myintent.getStringExtra("DISPLAY");
		String host = myintent.getStringExtra("HOST");
		String port = myintent.getStringExtra("PORT");
		
		//for now we are going to override:
		host = "aardmud.org";
		port = "4010";
		
		while(service == null) {
			host = "aardmud.org"; //waste time till onServiceConnected is called.
		}
		
		
		try {
			service.setConnectionData(host, new Integer(port).intValue());
		} catch (NumberFormatException e1) {
			//e1.printStackTrace();
		} catch (RemoteException e1) {
			//e1.printStackTrace();
		}
		
		
		
		
		
		
		//connect up the service and start pumping data
		try {
			service.initXfer();
		} catch (RemoteException e) {
			//e.printStackTrace();
		}
	}
	
	public void flingLeft() {
	    	Log.e("SCRO","SCROLL LEFT");
	    	FixedViewFlipper tmp = (FixedViewFlipper)findViewById(R.id.flippdipper);
	    	tmp.setInAnimation(AnimationUtils.loadAnimation(tmp.getContext(), R.anim.slide_left_in));
	    	tmp.setOutAnimation(AnimationUtils.loadAnimation(tmp.getContext(), R.anim.slide_left_out));
	    	tmp.showPrevious();
	    	
	    }
	    
	public void flingRight() {
	    	Log.e("SCRO","SCROLL RIGHT");
	    	FixedViewFlipper tmp = (FixedViewFlipper)findViewById(R.id.flippdipper);
	    	tmp.setOutAnimation(AnimationUtils.loadAnimation(tmp.getContext(), R.anim.slide_right_out));
	    	tmp.setInAnimation(AnimationUtils.loadAnimation(tmp.getContext(), R.anim.slide_right_in));
	    	tmp.showNext();
	    }
	
	
	private IBaardTERMServiceCallback.Stub the_callback = new IBaardTERMServiceCallback.Stub() {

		public void dataIncoming(byte[] seq) throws RemoteException {
			//create a new message and send it to my handler
			Message msg = myhandler.obtainMessage(MESSAGE_PROCESS);
			
			Bundle b = new Bundle();
			
			b.putByteArray("SEQ", seq);
			
			msg.setData(b);
			
			myhandler.sendMessage(msg);
			
		}

		public void processedDataIncoming(CharSequence seq) throws RemoteException {
				
			Message msg = myhandler.obtainMessage(MESSAGE_PROCESSED); 
			
			Bundle b = new Bundle();
			
			b.putCharSequence("SEQ", seq);
			
			msg.setData(b);
			
			myhandler.sendMessage(msg);
		}

		public void htmlDataIncoming(String html) throws RemoteException {
			Message msg = myhandler.obtainMessage(MESSAGE_HTMLINC);
			
			Bundle b = new Bundle();
			
			b.putString("HTML", html);
			
			msg.setData(b);
			
			myhandler.sendMessage(msg);
			
		}

		public void rawDataIncoming(String raw) throws RemoteException {
			Message msg = myhandler.obtainMessage(MESSAGE_RAWINC);
			
			Bundle b = new Bundle();
			
			b.putString("RAW",raw);
			
			msg.setData(b);
			
			myhandler.sendMessage(msg);
			
		}
		
		
		
	
		
	};

}
