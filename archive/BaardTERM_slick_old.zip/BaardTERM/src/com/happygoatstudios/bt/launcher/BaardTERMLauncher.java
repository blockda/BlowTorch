package com.happygoatstudios.bt.launcher;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.happygoatstudios.bt.R;

public class BaardTERMLauncher extends Activity implements ReadyListener {
	
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		
		//start the initializeations
		setContentView(R.layout.launcher_layout);
		
		
		//get the button
		Button b = (Button)findViewById(com.happygoatstudios.bt.R.id.startbutton);
		
		//make an appropriate listener to launch the connection picker dialog.
		b.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ConnectionPickerDialog dialog = new ConnectionPickerDialog(BaardTERMLauncher.this,BaardTERMLauncher.this);
				dialog.show();
			}
		});
		
	}
	
	//called when ConnectionPickerDialog returns.
    public void ready(String displayname,String host,String port) {
        /*connection = new Thread(this);
        connection.setName("Connection_Handler");
        connection.start();
        
		FixedViewFlipper vf = (FixedViewFlipper)findViewById(R.id.welcomeflipper);
		vf.showNext();
		
		synchronized(this) {
		try {
			this.wait(1000); //give the other thread time to start up.
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		Message tmp = ConnectionHandler.obtainMessage(100);
		ConnectionHandler.sendMessage(tmp);*/
    	
    	//start service
    	
    	//start window activity.
    	Intent the_intent = new Intent(com.happygoatstudios.bt.window.BaardTERMWindow.class.getName());
    	
    	the_intent.putExtra("DISPLAY",displayname);
    	the_intent.putExtra("HOST", host);
    	the_intent.putExtra("PORT", port);
    	
    	this.startActivity(the_intent);
    }

}
