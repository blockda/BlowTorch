package com.happygoatstudios.bt.window;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.happygoatstudios.bt.R;
import com.happygoatstudios.bt.service.Colorizer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class SlickView extends SurfaceView implements SurfaceHolder.Callback {

	Pattern colordata = Pattern.compile("\\x1B\\x5B(([0-9]{1,2});)?([0-9]{1,2})m");
	
	private DrawRunner _runner;
	
	private Pattern newline = Pattern.compile("\n");
	private Pattern carriage = Pattern.compile("\\x0D");
	
	private Float scrollback = new Float(0);
	
	private Boolean touchLock = new Boolean(false);
	
	private Boolean wasRunning = false;
	
	public SlickView(Context context) {
		super(context);
		getHolder().addCallback(this);
		_runner = new DrawRunner(getHolder(),this,touchLock);
	}
	
	public SlickView(Context context,AttributeSet attrib) {
		super(context,attrib);
		getHolder().addCallback(this);
		//_runner = new DrawRunner(getHolder(),this,touchLock);
		Log.e("VIEW","VIEW STARTING UP!");
	} 

	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	public void surfaceCreated(SurfaceHolder arg0) {
		Log.e("VIEW","SURFACE CREATED!");
		//if(!wasRunning) {
			_runner = new DrawRunner(getHolder(),this,touchLock);
			_runner.setRunning(true);
			_runner.start();
			wasRunning = true;
		//}
	}
	
	public void stopDrawing() {
		Log.e("SLICK","Attempted to kill/stop thread at stopDrawing()");
		boolean retry = true;
		_runner.setRunning(false);
		while(retry) {
			try{
				_runner.join();
				retry = false;
			} catch (InterruptedException e) { }
		}
		wasRunning = false;
		
		//_runner = null;
	}

	public void surfaceDestroyed(SurfaceHolder arg0) {
		boolean retry = true;
		_runner.setRunning(false);
		while(retry) {
			try{
				_runner.join();
				retry = false;
			} catch (InterruptedException e) { }
		}
		wasRunning = false;
	}
	
	StringBuffer the_buffer = new StringBuffer();
	
	public void addText(String input) {
		
		synchronized(touchLock) {
			while(touchLock.booleanValue()) {
				//if the lock is locked (true), sleep on it until it is false
				try {
					touchLock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			touchLock = true;
			//lock the lock
		}
		
		Matcher carriagerock = carriage.matcher(input);
		
		//Matcher toLines = newline.matcher();
		
		
		the_buffer.append(carriagerock.replaceAll(""));
	
		
        synchronized(touchLock) {
        	touchLock.notify();
        	touchLock = false;
        	//touchLock.notify();
        }
	}
	
	
	StringBuffer sel_color = new StringBuffer(new Integer(0xFFBBBBBB).toString());
	StringBuffer sel_bright = new StringBuffer(new Integer(0).toString()); 
	StringBuffer segment = new StringBuffer();
	@Override
	public void onDraw(Canvas canvas) {
		//IM DRAWING
	//if this is locked because of a touch event
	synchronized(touchLock) {
		while(touchLock.booleanValue()) {
			//if the lock is locked (true), sleep on it until it is false
			try {
				touchLock.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		touchLock = true;
		//lock the lock
	}
	
	//lock because of touching
	
		
		int TEXTSIZE = 18;
		int linesize = 20;
		//calculate screen offset and number of lines.
		int height = canvas.getHeight();
		
		
		int numberoflinesinwindow = (int)( height / linesize );
		int scrollbacklines = scrollback.intValue() / linesize;
		
		int remainder = (int) (height - (numberoflinesinwindow*linesize)) - 4 + ((int) scrollback.intValue() % linesize);
		
		if(remainder < 0) {
			Log.e("SLICK","WE HAVE A PROBLEM WITH WINDOW SIZE");
		}
		
		//first clear the background
		canvas.drawColor(0xFF000000); //fill with black
		//canvas.drawColor(0xFF333333); //fill with grey
        Paint opts = new Paint();
        opts.setAlpha(0);
        opts.setAntiAlias(true);
        //opts.setDither(true);
        opts.setARGB(255, 255, 255, 255);
        opts.setTextSize(TEXTSIZE);
        
        //opts.setStyle(Style.)
        opts.setTypeface(Typeface.MONOSPACE);
        /*canvas.drawText("####------     PAINT    ------##?###?#?#?#?##",0,0,opts);
        canvas.drawText("-----        -------      ||||| |||| Xxxxxxxx",0,13,opts);
        canvas.drawText("||                                         ||",0,26,opts);*/
        Matcher toLines = newline.matcher(the_buffer.toString());
        
        StringBuffer line = new StringBuffer();
        
        
        
        
        int currentline = 1;
        
        //count lines
        int numlines = countLines();
        int maxlines = numberoflinesinwindow; 
        
        
        
        int startDrawingAtLine = 1;
        if(numlines > maxlines) {
        	startDrawingAtLine = numlines - maxlines - scrollbacklines + 1;
        } else {
        	startDrawingAtLine = 1;
        }
        
       
        boolean endonnewline = false;
        while(toLines.find()) {
        	toLines.appendReplacement(line, "");
        	
        	
        	if(currentline >= startDrawingAtLine-1 && currentline <= (startDrawingAtLine + maxlines)) {
        		
        		int screenpos = currentline - startDrawingAtLine + 1;
        		int y_position =  ((screenpos*linesize)+remainder);
        		Matcher colormatch = colordata.matcher(line.toString());
        		
        		
        		float x_position = 0;
        		
        		boolean colorfound = false;
        		
        		while(colormatch.find()) {
        			colorfound = true;
        			//String bright = colormatch.group(2);
        			//String value = colormatch.group(3);
        			//if(bright == null) {
        			//	bright = "0";
        			//}
        			
        			
        			
        			
        			colormatch.appendReplacement(segment, "");
        			
        			//get color data
        			int color = Colorizer.getColorValue(new Integer(sel_bright.toString()), new Integer(sel_color.toString()));
        			opts.setColor(0xFF000000 | color);
        			
        			canvas.drawText(segment.toString(), x_position, y_position, opts);
        			x_position = x_position + opts.measureText(segment.toString());
        			segment.setLength(0);
        			
        			sel_bright.setLength(0);
        			sel_color.setLength(0);
        			sel_bright.append((colormatch.group(2) == null) ? "0" : colormatch.group(2));
        			sel_color.append(colormatch.group(3));
        		}
        		if(colorfound) {
        			int color = Colorizer.getColorValue(new Integer(sel_bright.toString()), new Integer(sel_color.toString()));
        			opts.setColor(0xFF000000 | color);
        			colormatch.appendTail(segment);
        			canvas.drawText(segment.toString(), x_position, y_position, opts);
        			segment.setLength(0);
        		}
        		
        		if(!colorfound) {
        			canvas.drawText(line.toString(), 0, y_position , opts);
        		}
        		
        		
        		
         
        	}
        	
        	//line = new StringBuffer();
        	line.setLength(0);
        	currentline++;
        	if(toLines.end() == the_buffer.length()) {
        		endonnewline = true;
        	}
        	
        }
        if(!endonnewline) {
        	
        	toLines.appendTail(line);
        	//canvas.drawText(line.toString(), 0, (currentline*linesize)+remainder+new Float(scrollback).intValue(), opts);
        	//Log.e("SLICK","APPENDED LINE TAIL" + line.toString());
        	
        	int screenpos = currentline - startDrawingAtLine + 1;
    		int y_position =  ((screenpos*linesize)+remainder);
    		//int alt_y_pos = ((screenpos*linesize));
    		opts.setColor(0xFF00CCCC);
    		//canvas.drawLine(0, y_position, canvas.getWidth(), y_position, opts);
    		//opts.setColor(0xFF00FFFF);
    		//canvas.drawLine(0, alt_y_pos, canvas.getWidth(), alt_y_pos, opts);
        	//int tmpy = ((currentline)*linesize)+remainder;
    		//opts.setColor(0xFF00CCCC);
    		/*--------------------------------------*/
    		
    		//int screenpos = currentline - startDrawingAtLine;
    		//int y_position =  ((screenpos*linesize)+remainder);
    		Matcher colormatch = colordata.matcher(line.toString());
    		
    		
    		float x_position = 0;
    		
    		boolean colorfound = false;
    		
    		while(colormatch.find()) {
    			colorfound = true;
    			//String bright = colormatch.group(2);
    			//String value = colormatch.group(3);
    			//if(bright == null) {
    			//	bright = "0";
    			//}
    			
    			
    			
    			
    			colormatch.appendReplacement(segment, "");
    			
    			//get color data
    			int color = Colorizer.getColorValue(new Integer(sel_bright.toString()), new Integer(sel_color.toString()));
    			opts.setColor(0xFF000000 | color);
    			
    			canvas.drawText(segment.toString(), x_position, y_position, opts);
    			x_position = x_position + opts.measureText(segment.toString());
    			segment.setLength(0);
    			
    			sel_bright.setLength(0);
    			sel_color.setLength(0);
    			sel_bright.append((colormatch.group(2) == null) ? "0" : colormatch.group(2));
    			sel_color.append(colormatch.group(3));
    		}
    		if(colorfound) {
    			int color = Colorizer.getColorValue(new Integer(sel_bright.toString()), new Integer(sel_color.toString()));
    			opts.setColor(0xFF000000 | color);
    			colormatch.appendTail(segment);
    			canvas.drawText(segment.toString(), x_position, y_position, opts);
    			segment.setLength(0);
    		}
    		
    		if(!colorfound) {
    			canvas.drawText(line.toString(), 0, y_position , opts);
    		}
    		/*--------------------------------------*/
        	//canvas.drawText(line.toString(), 0, y_position, opts);
        	//Log.e("VIEW","PROMPT:" + y_position + ":" + line.toString());
        	line.setLength(0);
        	currentline++;		
        	
        }
        
        //release the lock
        
        synchronized(touchLock) {
        	touchLock.notify();
        	touchLock = false;
        	//touchLock.notify();
        }
	}
	
	MotionEvent pre_event = null;
	Float prev_y = new Float(0.1);
	public boolean onTouchEvent(MotionEvent t) {
		
		synchronized(touchLock) {
			while(touchLock.booleanValue()) {
				//if the lock is locked (true), sleep on it until it is false
				try {
					touchLock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			touchLock = true;
			//lock the lock
		}
		//touchLock = true;
		//_runner.setPause();
		int pointers = t.getPointerCount();
		int the_last_pointer = t.getPointerId(0);
		float diff = 0;
		for(int i=0;i<pointers;i++) {
			
			Float y_val = new Float(t.getY(t.getPointerId(i)));
			Float x_val = new Float(t.getX(t.getPointerId(i)));
			if(pre_event == null) {
				diff = 0;
			} else {
				diff = y_val - prev_y;	
			}
			
			//Log.e("SLICK","SLICK TOUCH AT PY:" + prev_y + " Y:" + y_val + " P:" + i + " DIF:" + diff);
			prev_y = y_val;
		}
		
		scrollback = scrollback + diff;
		
		if(t.getAction() == (MotionEvent.ACTION_UP)) {
			Log.e("SLICK","Got up action: " + scrollback);
			pre_event = null;
			prev_y = new Float(0);
	        synchronized(touchLock) {
	        	touchLock.notify();
	        	touchLock = false;
	        }
			return true;
		}
		
		pre_event = MotionEvent.obtain(t);
		//_runner.setResume();
		
        synchronized(touchLock) {
        	touchLock.notify();
        	touchLock = false;
        }
		return true; //consumes
		
		//return false; //does not consume
	}
	
	
	
	/*public String breakLines(String input,int charcount) {
		StringBuffer holder = new StringBuffer();
		Matcher m = newline.matcher(input);
		
		//Character esc = new Character();
		StringBuffer line = new StringBuffer();
		StringBuffer segment = new StringBuffer();
		StringBuffer broken_line = new StringBuffer();
		while(m.find()) {
			m.appendReplacement(line, "");
			Matcher colormatch = colordata.matcher(line.toString());
			boolean found = false;
			while(colormatch.find()) {
				found = true;
				colormatch.appendReplacement(segment, colormatch.group());
				if(segment.length() > 50) {
					//get the next part of the line that is to be broken
					broken_line.append(segment.subSequence(0, 50));
					holder.append(broken_line.toString() + "\n");
					segment.replace(0, 50, "");
					broken_line.setLength(0);
				}
			} //if not found, perform break on whole line, because there are no colors to worry about
			
			//if found, perform line break ritual on appendtail.
			int seg = 0;
			if(!found) {
				
				while()
			}
			
			
		}
		
		return holder.toString();
		
	}*/
	public StringBuffer prompt_string = new StringBuffer();
	public StringBuffer garbage_string = new StringBuffer();
	public int countLines() {
		Matcher toLines = newline.matcher(the_buffer.toString());
		
		boolean endonnewline = false;
		int found = 0;
		while(toLines.find()) {
			found++;
			toLines.appendReplacement(garbage_string, "");
			garbage_string.setLength(0);
			if(toLines.end() == the_buffer.length()) {
				//ended on a new line
				endonnewline = true;
				//toLines.appendReplacement()
			}
		}
		if(!endonnewline) {
			//make sure to include the last, un-newline-terminated string, which should be the prompt
			found++;
			String prev_prompt = prompt_string.toString();
			prompt_string.setLength(0); //clear the prompt
			toLines.appendTail(prompt_string);
			if(!prev_prompt.equals(prompt_string.toString())) {
				Log.e("SLICK","NEW PROMT:" + prompt_string.toString());
			}
			
		}
		
		return found;
	}
	
	public class DrawRunner extends Thread {
		private SurfaceHolder _surfaceHolder;
		private SlickView _sv;
		private boolean running = false;
		private boolean paused = false;
		private Boolean lock = null;
		
		public DrawRunner(SurfaceHolder parent,SlickView view,Boolean drawlock) {
			_surfaceHolder = parent;
			_sv = view;
			lock = drawlock;
		}
		
		public void setRunning(boolean val) {
			running = val;
		}
		
		public void setPause() {
			paused = true;
		}
		
		public void setResume() {
			paused = false;
		}
		
		@Override
		public void run() {
			Canvas c;
			Log.e("SLICK","VIEW THREAD RUNNING");
			while(running) {
				if(!paused) {
					c = null;
					try{

						
						c = _surfaceHolder.lockCanvas(null);
						synchronized(_surfaceHolder) {
							_sv.onDraw(c);
							_surfaceHolder.notify();
						}
						

					} finally { 
						if(c != null) {
							_surfaceHolder.unlockCanvasAndPost(c);
						}
					}
				}
			}
		}
		
	}

}
